package me.stefan.notes;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public class NotesAdapter extends BaseAdapter {
    private final List<Note> notes;
    private final Context ctx;
    private final LayoutInflater inflater;
    private Drawable originalBgDrawable;

    public NotesAdapter(Context ctx, List<Note> notes) {
        this.ctx = ctx;
        this.notes = notes;
        this.inflater = (LayoutInflater) ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getCount() {
        return notes.size();
    }

    @Override
    public Object getItem(int i) {
        return notes.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Note n = notes.get(i);
        View listItem = (view == null) ? inflater.inflate(R.layout.listitem_note, null ) : view;
        ((TextView) listItem.findViewById(R.id.itemMessage)).setText(n.note);
        ((TextView) listItem.findViewById(R.id.itemDateTime)).setText("Date: " + n.date + " Time: " + n.time);
        if (originalBgDrawable != null)
            originalBgDrawable = listItem.getBackground();

        if (LocalDateTime.of(n.date,n.time).isAfter(LocalDateTime.now()))
            listItem.setBackgroundColor(ContextCompat.getColor(ctx, R.color.light_red));
        else
            listItem.setBackground(originalBgDrawable);

        return listItem ;
    }
}
